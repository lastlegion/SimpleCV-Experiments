Requirements:
  Python 2.7 or later with SimpleCV library installed.

Usage:
  Usage instructions are specified in the first line of each program

Report:
  The source file for the report is in the "reports" folder

